Task2 Prediction 

* Expectation: I predict that the supplier info in the product will still be displayed as the supplier class exist separately from the Product Class and only the external supplier variable is deleted and the referenced supplier info still exist in Product Class.



Task3 Prediction

* Expectation: Product will still work as it is removed from inventory A but the Product Class still exists as only its reference in the Inventory Class is removed from the program.



Task4 Prediction

* Expectation: Only one Product exists but there will be 2 OrderLine objects.



Task6 LSP Violation

* Yes, this violates LSP if Product promises that valid calls to update\_stock() will update its stock quantity, because substituting a DigitalProduct causes that operation to fail. For this lab’s stock-tracked model, I would remove the rejecting override and let DigitalProduct inherit the working Product.update\_stock() implementation. If digital products genuinely have no stock in the intended domain, I would instead move stock-specific behaviour out of the common Product abstraction.



Task7 Prediction

* Expectation: It will print None as get\_fulfilment\_info() does not return anything and the print is happening in the function itself.

